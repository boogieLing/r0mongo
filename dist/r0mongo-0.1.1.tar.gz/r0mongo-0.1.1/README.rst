About
-----

install latest commit on master of mongo-helper

::

  % pip3 install git+git://github.com/kenjyco/redis-helper
